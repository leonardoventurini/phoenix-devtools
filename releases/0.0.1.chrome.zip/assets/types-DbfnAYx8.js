var u=(t=>(t.WebSocket="websocket",t.Http="http",t))(u||{}),n=(t=>(t.Inbound="inbound",t.Outbound="outbound",t))(n||{});export{n as M,u as a};
